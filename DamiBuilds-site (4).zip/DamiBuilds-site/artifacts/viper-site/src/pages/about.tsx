import { motion } from "framer-motion";
import { Navigation } from "@/components/sections/Navigation";
import { Footer } from "@/components/sections/Footer";
import { Link } from "wouter";
import { ArrowRight, Zap, Globe, MessageCircle, Brain, Wrench, Rocket } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const skills = [
  { icon: <Zap size={16} />, label: "AI Automation" },
  { icon: <Globe size={16} />, label: "AI Websites" },
  { icon: <MessageCircle size={16} />, label: "AI Chatbots" },
  { icon: <Brain size={16} />, label: "Brand Strategy" },
];

const processSteps = [
  { num: "01", title: "Discovery Call", desc: "We talk about your goals, your audience, and the outcome you want. I listen first and ask the right questions before proposing anything." },
  { num: "02", title: "Scope & Plan", desc: "I scope the work, agree a clear timeline, and lock in deliverables. No surprises — just a clean plan you can hold me to." },
  { num: "03", title: "Build & Deliver", desc: "I build fast using the best AI tools, iterate with your feedback, and hand over a finished system ready to attract and convert clients." },
];

const services = [
  { num: "01", icon: <Zap size={20} />, title: "AI Automation", desc: "End-to-end workflow systems that eliminate repetitive tasks and free up your time." },
  { num: "02", icon: <Globe size={20} />, title: "AI Websites", desc: "Conversion-first, beautifully designed websites for coaches, authors, and speakers." },
  { num: "03", icon: <MessageCircle size={20} />, title: "AI Chatbots", desc: "Intelligent bots that qualify leads, book calls, and handle support 24/7." },
  { num: "04", icon: <Wrench size={20} />, title: "CRM & Email Automation", desc: "Automated follow-up and nurture sequences that convert your audience on autopilot." },
  { num: "05", icon: <Rocket size={20} />, title: "Sales Funnels", desc: "High-converting funnels that take your audience from cold to client, step by step." },
  { num: "06", icon: <Brain size={20} />, title: "AI Strategy", desc: "A clear digital roadmap tailored to your business — what to build, automate, and scale." },
];

const testimonials = [
  { name: "Holli McEachern", title: "Reentry Program Leader & Speaker", quote: "Daniel is intentional with his work. He doesn't just complete tasks — he thinks about how everything connects. The result was a cleaner online presence and systems that simply work better.", stars: 5 },
  { name: "Sorhaya Zamor, MSN", title: "Mental Health Coach & Author", quote: "He took the time to understand my vision and translated it into a cohesive, modern brand identity. His work on my website was seamless. Working with him was a stress-free and highly productive experience.", stars: 5 },
  { name: "Ty R. Graham", title: "Leadership Coach", quote: "DamiBuilds delivered exactly what I needed — a website that reflects my authority and speaks directly to the women I serve. The quality and speed was outstanding.", stars: 5 },
];

const faqs = [
  { q: "What makes DamiBuilds different from other freelancers?", a: "I specialise exclusively in coaches, authors, and speakers. Every system I build is designed around your specific client journey — not a generic template." },
  { q: "How fast can you deliver?", a: "Most website projects are done in 5–7 business days. Full automation builds take 1–2 weeks depending on complexity." },
  { q: "Do I need to be technical to work with you?", a: "Not at all. You just need to know your goals and your audience. I handle everything from strategy to delivery." },
  { q: "Can you work with my existing tools?", a: "Yes. Whether you're on GoHighLevel, HubSpot, Mailchimp, Calendly, or anything else — I integrate with your existing stack." },
  { q: "Do you offer ongoing support?", a: "Yes — I offer monthly retainer packages for maintenance, new automations, and priority support as your business grows." },
];

export function AboutPage() {
  return (
    <div className="bg-black min-h-screen text-foreground dark">
      <Navigation />
      <main className="pt-20">
        {/* Hero */}
        <section className="min-h-[90vh] flex items-center border-b border-border/40">
          <div className="mx-auto w-full max-w-[1100px] px-6 py-16">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <motion.div initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.7 }}>
                <span className="font-inter font-semibold text-[11px] uppercase tracking-[0.2em] text-white/40 block mb-6">About DamiBuilds</span>
                <h1 className="font-grotesk font-bold text-[60px] leading-[1.0] tracking-[-0.02em] mb-6">
                  The AI Specialist<br />
                  <span className="text-white/60">for Your Niche.</span>
                </h1>
                <p className="font-inter text-[16px] leading-relaxed text-muted-foreground mb-6 max-w-md">
                  DamiBuilds was founded on one belief: coaches, authors, and speakers deserve digital systems that actually work — not beautiful websites that don't convert.
                </p>
                <p className="font-inter text-[15px] leading-relaxed text-muted-foreground mb-10 max-w-md">
                  I build websites, automation systems, and AI tools that help you attract the right clients, look credible online, and grow — without spending all day on your phone.
                </p>
                <div className="flex flex-wrap gap-3 mb-10">
                  {skills.map((s) => (
                    <span key={s.label} className="inline-flex items-center gap-2 border border-white/20 rounded-full px-4 py-2 font-inter text-[13px] text-white/60 hover:border-white/40 hover:text-white/80 transition-colors">
                      {s.icon}{s.label}
                    </span>
                  ))}
                </div>
                <Link href="/contact">
                  <span className="inline-flex items-center gap-2 bg-white text-black font-inter font-semibold text-[13px] rounded-full px-7 py-3 hover:bg-white/90 transition-colors cursor-pointer">
                    Work With Me <ArrowRight size={14} />
                  </span>
                </Link>
              </motion.div>
              <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8, delay: 0.15 }} className="relative">
                <div className="relative rounded-2xl overflow-hidden aspect-[4/5] bg-card border border-border/30 max-w-md mx-auto">
                  <img src="/profile.jpg" alt="Damilare Ayodele — DamiBuilds" className="w-full h-full object-cover object-top" />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/50 via-transparent to-transparent" />
                  <div className="absolute bottom-6 left-6 right-6">
                    <div className="bg-card/85 backdrop-blur-md rounded-xl p-5 border border-border/50">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
                        <span className="font-inter text-[11px] uppercase tracking-[0.2em] text-white/50 font-semibold">Available for Projects</span>
                      </div>
                      <p className="font-grotesk font-semibold text-[16px] text-foreground">damilareayodele.com</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Process */}
        <section className="border-b border-border/40 bg-black py-24">
          <div className="mx-auto w-full max-w-[1100px] px-6">
            <p className="mb-3 font-inter text-[11px] font-semibold uppercase tracking-[0.22em] text-white/40">How it works</p>
            <h2 className="mb-12 font-grotesk text-[48px] font-semibold leading-[1.0] tracking-tight">The Process</h2>
            <div className="grid gap-6 md:grid-cols-3">
              {processSteps.map((step) => (
                <div key={step.num} className="rounded-2xl border border-border/40 bg-zinc-900/50 p-6">
                  <span className="mb-4 block font-inter text-[11px] font-semibold uppercase tracking-[0.2em] text-orange-500">{step.num}</span>
                  <h3 className="mb-3 font-grotesk text-[20px] font-semibold tracking-tight">{step.title}</h3>
                  <p className="font-inter text-[13px] leading-relaxed text-muted-foreground">{step.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Services */}
        <section className="border-b border-border/40 bg-black py-24">
          <div className="mx-auto w-full max-w-[1100px] px-6">
            <p className="mb-3 font-inter text-[11px] font-semibold uppercase tracking-[0.22em] text-white/40">What I build</p>
            <h2 className="mb-12 font-grotesk text-[48px] font-semibold leading-[1.0] tracking-tight">Services</h2>
            <div className="grid gap-px border border-border/40 rounded-2xl overflow-hidden md:grid-cols-2 lg:grid-cols-3">
              {services.map((s) => (
                <div key={s.num} className="bg-zinc-900/60 p-6 hover:bg-zinc-900 transition-colors">
                  <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/70">{s.icon}</div>
                  <h3 className="mb-2 font-grotesk text-[16px] font-semibold">{s.title}</h3>
                  <p className="font-inter text-[12px] leading-relaxed text-muted-foreground">{s.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="border-b border-border/40 bg-black py-24">
          <div className="mx-auto w-full max-w-[1100px] px-6">
            <p className="mb-3 font-inter text-[11px] font-semibold uppercase tracking-[0.22em] text-white/40">Client results</p>
            <h2 className="mb-12 font-grotesk text-[48px] font-semibold leading-[1.0] tracking-tight">What They Say</h2>
            <div className="grid gap-6 md:grid-cols-3">
              {testimonials.map((t) => (
                <div key={t.name} className="rounded-2xl border border-border/40 bg-zinc-900/50 p-6">
                  <div className="mb-4 flex gap-0.5">{Array.from({ length: t.stars }).map((_, j) => <span key={j} className="text-yellow-400 text-[13px]">★</span>)}</div>
                  <p className="mb-6 font-inter text-[14px] leading-relaxed text-foreground/80">"{t.quote}"</p>
                  <div className="border-t border-border/40 pt-4">
                    <p className="font-inter text-[13px] font-semibold text-foreground">{t.name}</p>
                    <p className="font-inter text-[12px] text-muted-foreground">{t.title}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="bg-black py-24">
          <div className="mx-auto w-full max-w-[700px] px-6">
            <p className="mb-3 font-inter text-[11px] font-semibold uppercase tracking-[0.22em] text-white/40">Common questions</p>
            <h2 className="mb-12 font-grotesk text-[48px] font-semibold leading-[1.0] tracking-tight">FAQs</h2>
            <Accordion type="single" collapsible className="space-y-2">
              {faqs.map((faq, i) => (
                <AccordionItem key={i} value={`faq-${i}`} className="border border-border/40 rounded-xl px-5">
                  <AccordionTrigger className="font-inter text-[14px] text-left">{faq.q}</AccordionTrigger>
                  <AccordionContent className="font-inter text-[13px] leading-relaxed text-muted-foreground">{faq.a}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
