import { Navigation } from "@/components/sections/Navigation";
import { Hero } from "@/components/sections/Hero";
import { Services } from "@/components/sections/Services";
import { Testimonials } from "@/components/sections/Testimonials";
import { ProcessSection } from "@/components/sections/ProcessSection";
import { Footer } from "@/components/sections/Footer";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles, Bot, Globe2, Wrench, Brain, MessageCircle } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";

const faqs = [
  { q: "What services do you provide?", a: "I specialise in AI-powered websites, sales funnels, automation systems, AI chatbots, and lead generation — built specifically for coaches, authors, and speakers." },
  { q: "How do I start working with you?", a: "Book a free discovery call. We'll map your goals, identify what systems you need, and get started — usually within 48 hours of agreement." },
  { q: "What tools do you use?", a: "I work across n8n, Make.com, Zapier, GoHighLevel, OpenAI, Framer, Webflow, and custom-coded stacks — whatever best fits your project and budget." },
  { q: "How long does a project take?", a: "A landing page is typically 3–5 days. A full automation build or website ranges from 1–3 weeks. Rush delivery is available." },
  { q: "Do you provide revisions?", a: "Yes — all plans include structured revision rounds. I iterate with you until the output matches your vision exactly." },
  { q: "What industries do you work with?", a: "Primarily coaches, authors, speakers, and service-based entrepreneurs. If you have a business that needs to attract and convert clients online, I can help." },
  { q: "Do you offer ongoing support?", a: "Absolutely. I offer monthly retainer packages that cover maintenance, new automations, optimisation, and priority turnaround as your business grows." },
  { q: "What is your pricing structure?", a: "I offer project-based, subscription, and retainer pricing designed to suit solopreneurs through to growing businesses. See the Pricing page for full details." },
  { q: "Can you redesign my existing website?", a: "Yes. I regularly rebuild and upgrade existing sites — migrating to faster, smarter stacks with AI features built in from day one." },
];

const tags = ["AI Automation", "Website Design", "Sales Funnels", "Lead Gen", "Brand Strategy", "Chatbots"];

const featureCards = [
  { icon: Sparkles, title: "Brand Systems", text: "Launch a sharp, credible online presence that reflects your authority and speaks directly to your ideal client." },
  { icon: Bot, title: "AI Workflows", text: "Automate lead handling, follow-ups, and client onboarding with high-leverage AI automation flows." },
  { icon: Globe2, title: "Web & Funnels", text: "Build high-converting websites and sales funnels with clear messaging and a single conversion goal." },
  { icon: MessageCircle, title: "AI Chatbots", text: "Deploy chatbots on WhatsApp and your website that qualify leads and book calls while you sleep." },
  { icon: Wrench, title: "CRM & Email", text: "Build automated email sequences and CRM pipelines that nurture your audience and convert consistently." },
  { icon: Brain, title: "Strategy Layer", text: "Get a clear digital roadmap — what to build, what to automate, and what to scale next." },
];

function FAQAccordion({ items }: { items: typeof faqs }) {
  const [open, setOpen] = useState(0);
  return (
    <div className="divide-y divide-border/40">
      {items.map((item, i) => (
        <div key={item.q} className="py-5">
          <button onClick={() => setOpen(open === i ? -1 : i)} className="flex w-full items-center justify-between gap-4 text-left">
            <span className="font-inter text-[14px] text-foreground">{item.q}</span>
            <span className="flex-shrink-0 text-2xl font-light leading-none text-white/40 transition-transform" style={{ transform: open === i ? 'rotate(45deg)' : 'none' }}>+</span>
          </button>
          {open === i && <p className="mt-4 max-w-[480px] font-inter text-[13px] leading-relaxed text-muted-foreground">{item.a}</p>}
        </div>
      ))}
    </div>
  );
}

export function HomePage() {
  return (
    <div className="min-h-screen bg-black text-foreground dark">
      <Navigation />
      <main>
        <Hero />

        {/* About Dami section */}
        <section className="w-full border-t border-white/10 bg-black py-32">
          <div className="mx-auto w-full max-w-[1200px] px-6">
            <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
              <div>
                <p className="mb-3 font-inter text-[11px] font-semibold uppercase tracking-[0.22em] text-white/40">Meet Dami</p>
                <h2 className="mb-5 font-grotesk text-[52px] font-semibold leading-[1.0] tracking-tight">Meet Dami.</h2>
                <p className="max-w-[520px] font-inter text-[15px] leading-relaxed text-white/65">Damilare Ayodele is the founder behind DamiBuilds — helping coaches, authors, and speakers build websites, automation systems, and AI tools that attract and convert clients consistently.</p>
                <p className="mt-4 max-w-[520px] font-inter text-[15px] leading-relaxed text-white/65">He blends brand strategy, AI automation, and conversion design so every system he builds is clear, intentional, and ready to grow.</p>
                <div className="mt-8 flex flex-wrap gap-3">
                  {tags.map((tag) => <span key={tag} className="rounded-full border border-white/20 px-4 py-2 font-inter text-[12px] text-white/60">{tag}</span>)}
                </div>
              </div>
              <div className="overflow-hidden rounded-3xl">
                <img src="/profile.jpg" alt="Damilare Ayodele" className="aspect-[4/5] h-full w-full object-cover object-top grayscale contrast-[1.1] brightness-[0.84]" />
              </div>
            </div>
          </div>
        </section>

        <ProcessSection />
        <Services />
        <Testimonials />

        {/* FAQ */}
        <section className="w-full border-t border-border/40 bg-black py-32">
          <div className="mx-auto w-full max-w-[1100px] px-6">
            <div className="grid min-h-[520px] items-start gap-12 lg:grid-cols-2">
              <div className="flex flex-col gap-8">
                <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}>
                  <p className="mb-3 font-inter text-[11px] font-semibold uppercase tracking-[0.2em] text-white/40">FAQs</p>
                  <h2 className="mb-4 font-grotesk text-[52px] font-semibold leading-[1.0] tracking-tight">Answers</h2>
                  <p className="max-w-[300px] font-inter text-[14px] leading-relaxed text-muted-foreground">Find answers to common questions about my process, services, and delivery.</p>
                </motion.div>
                <div>
                  <div className="mb-5 flex flex-wrap gap-2">
                    {["AI Automation", "AI Websites", "AI Chatbots"].map((tag) => (
                      <span key={tag} className="rounded-full border border-white/20 px-4 py-1.5 font-inter text-[12px] text-white/60">{tag}</span>
                    ))}
                  </div>
                  <Link href="/contact">
                    <span className="inline-flex cursor-pointer items-center gap-2 rounded-full border border-white/20 px-6 py-2.5 font-inter text-[13px] font-semibold text-white/70 transition-colors hover:border-white/50 hover:text-white">Book a Free Call <ArrowRight size={13} /></span>
                  </Link>
                </div>
              </div>
              <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }} className="lg:pt-2">
                <FAQAccordion items={faqs} />
              </motion.div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
