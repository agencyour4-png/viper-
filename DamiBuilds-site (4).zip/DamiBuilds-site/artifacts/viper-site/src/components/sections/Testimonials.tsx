import { motion } from "framer-motion";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { useEffect, useState } from "react";

const testimonials = [
  {
    id: 1,
    name: "Holli McEachern",
    title: "Speaker & Reentry Program Leader",
    quote: "What stood out to me was how intentional he is with his work. He doesn't just complete tasks — he thinks about how everything connects. The result was a cleaner online presence and systems that simply work better.",
    stars: 5,
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=100&h=100&fit=crop",
  },
  {
    id: 2,
    name: "Sorhaya Zamor, MSN",
    title: "Mental Health Coach & Author",
    quote: "He took the time to understand my vision and translated it into a cohesive, modern brand identity. His work on my website was seamless, and his designs elevated my content. Working with him was a stress-free and highly productive experience.",
    stars: 5,
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
  },
  {
    id: 3,
    name: "Ty R. Graham",
    title: "Leadership Coach",
    quote: "DamiBuilds delivered a clean, credible, conversion-focused website that reflects my authority and speaks directly to my audience — driven, ambitious women ready to level up. Outstanding quality and speed.",
    stars: 5,
    avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100&h=100&fit=crop",
  },
  {
    id: 4,
    name: "Business Coach",
    title: "Service-Based Entrepreneur",
    quote: "The automation workflows Dami built save me over 20 hours a week. My leads are now captured, followed up with, and nurtured automatically. It paid for itself within the first month.",
    stars: 5,
    avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop",
  },
  {
    id: 5,
    name: "Online Course Creator",
    title: "Author & Digital Educator",
    quote: "I had been putting off my website for 6 months. Dami launched it in under 2 weeks and it looked better than anything I imagined. I booked 3 discovery calls in the first 10 days.",
    stars: 5,
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
  },
];

function TestimonialCard({ t }: { t: typeof testimonials[0] }) {
  return (
    <div className="w-[320px] flex-shrink-0 rounded-[18px] border border-border/40 bg-zinc-900/50 p-7 transition-colors hover:border-border/70">
      <div>
        <div className="mb-4 flex gap-0.5">
          {Array.from({ length: t.stars }).map((_, j) => <span key={j} className="text-[13px] text-yellow-400">★</span>)}
        </div>
        <p className="mb-6 font-inter text-[14px] leading-relaxed text-foreground/80">"{t.quote}"</p>
      </div>
      <div className="flex items-center gap-3 border-t border-border/40 pt-5">
        <img src={t.avatar} alt={t.name} loading="lazy" className="h-9 w-9 flex-shrink-0 rounded-full object-cover object-center border border-white/20" />
        <div>
          <p className="font-inter text-[13px] font-semibold text-foreground">{t.name}</p>
          <p className="font-inter text-[11px] text-muted-foreground">{t.title}</p>
        </div>
      </div>
    </div>
  );
}

export function Testimonials() {
  const doubled = [...testimonials, ...testimonials];
  return (
    <section className="w-full border-t border-border/40 bg-black py-32 overflow-hidden">
      <div className="mx-auto w-full max-w-[1100px] px-6 mb-12">
        <motion.div initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }} className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
          <div>
            <p className="mb-3 font-inter text-[11px] font-semibold uppercase tracking-[0.22em] text-white/40">Client results</p>
            <h2 className="font-grotesk text-[52px] font-semibold leading-[0.96] tracking-tight">What They Say</h2>
          </div>
          <Link href="/contact">
            <span className="inline-flex cursor-pointer items-center gap-2 rounded-full border border-white/20 px-6 py-2.5 font-inter text-[13px] font-semibold text-white/70 transition-colors hover:border-white/50 hover:text-white">
              Work With Me <ArrowRight size={13} />
            </span>
          </Link>
        </motion.div>
      </div>
      <div className="relative">
        <div className="pointer-events-none absolute left-0 top-0 bottom-0 z-10 w-24" style={{ background: 'linear-gradient(to right, black, transparent)' }} />
        <div className="pointer-events-none absolute right-0 top-0 bottom-0 z-10 w-24" style={{ background: 'linear-gradient(to left, black, transparent)' }} />
        <div className="flex gap-4 px-6" style={{ animation: 'marquee 35s linear infinite', width: 'max-content' }}>
          {doubled.map((t, i) => <TestimonialCard key={i} t={t} />)}
        </div>
      </div>
    </section>
  );
}
